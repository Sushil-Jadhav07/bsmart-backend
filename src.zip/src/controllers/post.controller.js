const Post = require('../models/Post');
const User = require('../models/User');
const Comment = require('../models/Comment');
const sendNotification = require('../utils/sendNotification');

// Helper to transform post with fileUrl, is_liked_by_me, is_saved_by_me
const transformPost = (post, baseUrl, currentUserId = null, savedSet = null) => {
  const postObj = post.toObject ? post.toObject() : post;
  
  postObj.post_id = postObj._id;
  if (postObj.media && Array.isArray(postObj.media)) {
    postObj.media = postObj.media.map(item => {
      const fileUrl = item.fileName ? `${baseUrl}/uploads/${item.fileName}` : item.fileUrl;
      let thumbnailArray = [];
      if (Array.isArray(item.thumbnails)) {
        thumbnailArray = item.thumbnails.map(t => ({
          ...t,
          fileUrl: t.fileName ? `${baseUrl}/uploads/${t.fileName}` : t.fileUrl
        }));
      } else if (item.thumbnail && item.thumbnail.fileName) {
        thumbnailArray = [{
          ...item.thumbnail,
          fileUrl: `${baseUrl}/uploads/${item.thumbnail.fileName}`
        }];
      }
      return {
        ...item,
        fileUrl,
        thumbnail: thumbnailArray
      };
    });
  }

  if (currentUserId && postObj.likes) {
    postObj.is_liked_by_me = postObj.likes.some(id => id.toString() === currentUserId.toString());
  } else {
    postObj.is_liked_by_me = false;
  }
  
  if (savedSet && typeof postObj._id !== 'undefined') {
    postObj.is_saved_by_me = savedSet.has(postObj._id.toString());
  } else {
    postObj.is_saved_by_me = false;
  }
  
  return postObj;
};

// @desc    Create a new post
// @route   POST /api/posts
// @access  Private
exports.createPost = async (req, res) => {
  try {
    const { caption, location, media, tags, people_tags, hide_likes_count, turn_off_commenting, type } = req.body;

    // Validate media
    if (!media || media.length === 0) {
      return res.status(400).json({ message: 'At least one media item is required' });
    }

    const validCropModes = ["original", "1:1", "4:5", "16:9"];

    for (const item of media) {
      if (!item.fileName) {
        return res.status(400).json({ message: 'Each media item must have a fileName' });
      }
      if (item.crop && item.crop.mode && !validCropModes.includes(item.crop.mode)) {
        return res.status(400).json({ message: `Invalid crop mode: ${item.crop.mode}` });
      }
    }

    const post = await Post.create({
      user_id: req.userId,
      caption,
      location,
      media,
      tags,
      people_tags,
      hide_likes_count,
      turn_off_commenting,
      type
    });

    // Increment user posts_count
    await User.findByIdAndUpdate(req.userId, { $inc: { posts_count: 1 } });

    try {
      if (Array.isArray(people_tags) && people_tags.length > 0) {
        const creator = await User.findById(req.userId).select('username').lean();
        for (const taggedUserId of people_tags) {
          if (taggedUserId.toString() !== req.userId.toString()) {
            await sendNotification(req.app, {
              recipient: taggedUserId,
              sender: req.userId,
              type: 'post_tag',
              message: `${creator.username} tagged you in a post`,
              link: `/posts/${post._id}`
            });
          }
        }
      }
    } catch (notifErr) {
      console.error('Tag notification error:', notifErr);
    }

    // Populate user info immediately for the response
    const populatedPost = await post.populate('user_id', 'username full_name avatar_url followers_count following_count');

    const baseUrl = `${req.protocol}://${req.get('host')}`;
    res.status(201).json(transformPost(populatedPost, baseUrl));
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get posts feed
// @route   GET /api/posts/feed
// @access  Private
exports.getFeed = async (req, res) => {
  try {
    const posts = await Post.find()
      .sort({ createdAt: -1 })
      .populate('user_id', 'username full_name avatar_url followers_count following_count');

    const baseUrl = `${req.protocol}://${req.get('host')}`;
    // Prefetch saved post IDs for current user to compute is_saved_by_me
    const SavedPost = require('../models/SavedPost');
    const saved = await SavedPost.find({ user_id: req.userId }).select('post_id').lean();
    const savedSet = new Set(saved.map(s => s.post_id.toString()));
    const transformedPosts = posts.map(post => transformPost(post, baseUrl, req.userId, savedSet));

    res.json(transformedPosts);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get single post
// @route   GET /api/posts/:id
// @access  Private
exports.getPost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id)
      .populate('user_id', 'username full_name avatar_url followers_count following_count');

    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    // Fetch comments for the post
    const commentsRaw = await Comment.find({ post_id: req.params.id })
      .sort({ createdAt: -1 });

    const baseUrl = `${req.protocol}://${req.get('host')}`;
    const SavedPost = require('../models/SavedPost');
    const isSaved = await SavedPost.exists({ user_id: req.userId, post_id: post._id });
    const savedSet = new Set();
    if (isSaved) savedSet.add(post._id.toString());
    const transformedPost = transformPost(post, baseUrl, req.userId, savedSet);
    
    transformedPost.comments = commentsRaw.map(c => {
      const obj = c.toObject ? c.toObject() : c;
      obj.comment_id = obj._id;
      return obj;
    });

    res.json(transformedPost);
  } catch (error) {
    console.error(error);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ message: 'Post not found' });
    }
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Delete post
// @route   DELETE /api/posts/:id
// @access  Private
exports.deletePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);

    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    // Check ownership
    if (post.user_id.toString() !== req.userId.toString()) {
      return res.status(403).json({ message: 'Not authorized to delete this post' });
    }

    await post.deleteOne();

    // Decrement user posts_count
    await User.findByIdAndUpdate(req.userId, { $inc: { posts_count: -1 } });

    res.json({ message: 'Post deleted successfully' });
  } catch (error) {
    console.error(error);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ message: 'Post not found' });
    }
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

exports.createReel = async (req, res) => {
  try {
    const { caption, location, media, tags, people_tags, hide_likes_count, turn_off_commenting } = req.body;

    if (!media || media.length === 0) {
      return res.status(400).json({ message: 'At least one media item is required' });
    }

    // Normalize incoming requested keys
    const normalizedMedia = media.map(m => {
      const nm = { ...m };
      if (Array.isArray(nm.thumbnail)) {
        nm.thumbnails = nm.thumbnail;
        delete nm.thumbnail;
      }
      if (typeof nm['finalLength-start'] !== 'undefined') {
        nm.finalLength_start = nm['finalLength-start'];
      }
      if (typeof nm['finallength-end'] !== 'undefined') {
        nm.finalLength_end = nm['finallength-end'];
      }
      if (typeof nm['thumbail-time'] !== 'undefined') {
        nm.thumbnail_time = nm['thumbail-time'];
      }
      if (typeof nm.totalLenght !== 'undefined') {
        nm.totalLength = nm.totalLenght;
      }
      return nm;
    });

    const validCropModes = ["original", "1:1", "4:5", "16:9"];
    for (const item of media) {
      if (!item.fileName) {
        return res.status(400).json({ message: 'Each media item must have a fileName' });
      }
      if (item.crop && item.crop.mode && !validCropModes.includes(item.crop.mode)) {
        return res.status(400).json({ message: `Invalid crop mode: ${item.crop.mode}` });
      }
    }

    const post = await Post.create({
      user_id: req.userId,
      caption,
      location,
      media: normalizedMedia,
      tags,
      people_tags,
      hide_likes_count,
      turn_off_commenting,
      type: 'reel'
    });

    await User.findByIdAndUpdate(req.userId, { $inc: { posts_count: 1 } });
    const populatedPost = await post.populate('user_id', 'username full_name avatar_url followers_count following_count');
    const baseUrl = `${req.protocol}://${req.get('host')}`;
    res.status(201).json(transformPost(populatedPost, baseUrl));
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

exports.listReels = async (req, res) => {
  try {
    const posts = await Post.find({ type: 'reel' })
      .sort({ createdAt: -1 })
      .populate('user_id', 'username full_name avatar_url followers_count following_count');

    const baseUrl = `${req.protocol}://${req.get('host')}`;
    const SavedPost = require('../models/SavedPost');
    const saved = await SavedPost.find({ user_id: req.userId }).select('post_id').lean();
    const savedSet = new Set(saved.map(s => s.post_id.toString()));
    const transformed = posts.map(p => transformPost(p, baseUrl, req.userId, savedSet));
    res.json(transformed);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

exports.getReelById = async (req, res) => {
  try {
    const post = await Post.findOne({ _id: req.params.id, type: 'reel' })
      .populate('user_id', 'username full_name avatar_url followers_count following_count');

    if (!post) {
      return res.status(404).json({ message: 'Reel not found' });
    }

    const commentsRaw = await Comment.find({ post_id: req.params.id })
      .sort({ createdAt: -1 });

    const baseUrl = `${req.protocol}://${req.get('host')}`;
    const SavedPost = require('../models/SavedPost');
    const isSaved = await SavedPost.exists({ user_id: req.userId, post_id: post._id });
    const savedSet = new Set();
    if (isSaved) savedSet.add(post._id.toString());
    const transformedPost = transformPost(post, baseUrl, req.userId, savedSet);
    transformedPost.comments = commentsRaw.map(c => {
      const obj = c.toObject ? c.toObject() : c;
      obj.comment_id = obj._id;
      return obj;
    });

    res.json(transformedPost);
  } catch (error) {
    console.error(error);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ message: 'Reel not found' });
    }
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};
