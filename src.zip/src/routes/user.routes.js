const express = require('express');
const router = express.Router();
const { getAllUsers, getUserById, updateUser, deleteUser, getUserPostsDetails, listUsersProfiles, updateUserStatus } = require('../controllers/user.controller');
const { getSavedPostsByUser } = require('../controllers/saved.controller');
const { getFollowers, getFollowing } = require('../controllers/follow.controller');
const auth = require('../middleware/auth');

/**
 * @swagger
 * tags:
 *   name: Users
 *   description: User management
 */


/**
 * @swagger
 * /api/users:
 *   get:
 *     summary: Get list of user profiles with posts, comments, likes, and views
 *     tags: [Users]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of user profiles with aggregated data
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   user:
 *                     $ref: '#/components/schemas/User'
 *                   summary:
 *                     type: object
 *                     properties:
 *                       posts_count: { type: number }
 *                       reels_count: { type: number }
 *                       likes_count_total: { type: number }
 *                       comments_count_total: { type: number }
 *                       views_count_total: { type: number }
 *                       unique_views_count_total: { type: number }
 *                       completed_views_count_total: { type: number }
 *                   posts:
 *                     type: array
 *                     items:
 *                       $ref: '#/components/schemas/Post'
 *             examples:
 *               sample:
 *                 value:
 *                   - user:
 *                       id: "60f1b2c3d4e5f67890123456"
 *                       username: "john_doe"
 *                       email: "john@example.com"
 *                       full_name: "John Doe"
 *                       avatar_url: ""
 *                       phone: "+910000000000"
 *                       gender: "male"
 *                       location: "Mumbai, India"
 *                       role: "member"
 *                       followers_count: 10
 *                       following_count: 5
 *                       createdAt: "2026-03-10T06:14:50.531Z"
 *                       updatedAt: "2026-03-10T06:14:50.531Z"
 *                     summary:
 *                       posts_count: 2
 *                       reels_count: 1
 *                       likes_count_total: 5
 *                       comments_count_total: 3
 *                       views_count_total: 200
 *                       unique_views_count_total: 150
 *                       completed_views_count_total: 120
 *                     posts: []
 *       401:
 *         description: Not authorized
 *       500:
 *         description: Server error
 */
router.get('/', auth, listUsersProfiles);

/**
 * @swagger
 * /api/users/{id}:
 *   get:
 *     summary: Get user details
 *     tags: [Users]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *         description: User ID
 *     responses:
 *       200:
 *         description: User details
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 *             examples:
 *               user:
 *                 value:
 *                   id: "60f1b2c3d4e5f67890123456"
 *                   username: "john_doe"
 *                   email: "john@example.com"
 *                   full_name: "John Doe"
 *                   avatar_url: ""
 *                   phone: "+910000000000"
 *                   gender: "male"
 *                   location: "Mumbai, India"
 *                   role: "member"
 *                   followers_count: 10
 *                   following_count: 5
 *                   createdAt: "2026-03-10T06:14:50.531Z"
 *                   updatedAt: "2026-03-10T06:14:50.531Z"
 *       404:
 *         description: User not found
 *       500:
 *         description: Server error
 */
router.get('/:id', getUserById);

/**
 * @swagger
 * /api/users/{id}/posts:
 *   get:
 *     summary: Get user's posts with comments and likes
 *     tags: [Users]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *         description: User ID
 *     responses:
 *       200:
 *         description: List of posts with comments and likes
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Post'
 *       404:
 *         description: User not found
 *       500:
 *         description: Server error
 */
router.get('/:id/posts', getUserPostsDetails);
router.get('/:id/followers', getFollowers);
router.get('/:id/following', getFollowing);
router.get('/:id/saved', auth, getSavedPostsByUser);

/**
 * @swagger
 * /api/users/{id}:
 *   put:
 *     summary: Update user details
 *     tags: [Users]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *         description: User ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               full_name:
 *                 type: string
 *               bio:
 *                 type: string
 *               avatar_url:
 *                 type: string
 *               phone:
 *                 type: string
 *               username:
 *                 type: string
 *               gender:
 *                 type: string
 *                 description: User gender (e.g. male, female, other)
 *                 example: "male"
 *               location:
 *                 type: string
 *                 description: User location (city, country, etc.)
 *                 example: "Mumbai, India"
 *     responses:
 *       200:
 *         description: User updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 *       403:
 *         description: Not authorized
 *       404:
 *         description: User not found
 *       500:
 *         description: Server error
 */
router.put('/:id', auth, updateUser);

/**
 * @swagger
 * /api/users/{id}/status:
 *   patch:
 *     summary: Update user active status
 *     tags: [Users]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *         description: User ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               admin_user_id:
 *                 type: string
 *                 description: Admin user ID performing this action
 *               is_active:
 *                 type: boolean
 *     responses:
 *       200:
 *         description: User status updated successfully
 *       400:
 *         description: Validation error
 *       403:
 *         description: Not authorized
 *       404:
 *         description: User not found
 *       500:
 *         description: Server error
 */
router.patch('/:id/status', auth, updateUserStatus);

/**
 * @swagger
 * /api/users/{id}:
 *   delete:
 *     summary: Delete user and their posts
 *     tags: [Users]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *         description: User ID
 *     responses:
 *       200:
 *         description: User deleted successfully
 *       403:
 *         description: Not authorized
 *       404:
 *         description: User not found
 *       500:
 *         description: Server error
 */
router.delete('/:id', auth, deleteUser);

module.exports = router;
